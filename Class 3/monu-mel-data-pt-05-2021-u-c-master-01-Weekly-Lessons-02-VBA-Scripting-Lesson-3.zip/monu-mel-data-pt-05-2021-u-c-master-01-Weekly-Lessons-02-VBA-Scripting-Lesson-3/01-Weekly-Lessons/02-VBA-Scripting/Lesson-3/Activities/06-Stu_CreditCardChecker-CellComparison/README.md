# Credit Card Checker

## Instructions

* Create a VBA script that will process the credit card purchases, identifying each of the unique brands listed.

* For the _Basic_ assignment, create a single pop-up message for each of the Credit Card brands listed by looping through the list.

* For the _Advanced_ assignment, tally the total credit card purchases for each Credit Card brand and add it to the summary table.

## Notes

* This assignment is extremely similar to the basic version of the homework assignment. So let's buckle down and analyze this!
